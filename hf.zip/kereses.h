#ifndef KERESES_H_INCLUDED
#define KERESES_H_INCLUDED

void kiirtalalat(int *szamoz, lista *mozgo);
void valasztas(int *mit, int *ezt);
void idokeres(lista *eleje);
lista *keres(lista *eleje, int menupont);
void nevkeres(lista *eleje);

#endif
