#ifndef TOROL_H_INCLUDED
#define TOROL_H_INCLUDED

lista *eltavolit(lista *eleje,int *melyik, int ezt, lista *lemarado, lista *mozgo);
lista *torol(int sorszam,lista *eleje,int egyes,int kettes,char *keres);

#endif
